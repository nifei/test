#!/bin/bash

echo `date`>>start.dat

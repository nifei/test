#!/bin/bash

echo '{{ server_IP }}'>>server_peer_id.sh

#!/bin/bash

echo '{{ client_IP }}'>>start.dat
